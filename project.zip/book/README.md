# Book social network

Social network project for books with old school theme of windows XP(folder).

Every guest can come and see a lot of books, people were posted and also after registering can upload his own favourite books,

It's still everything is base, what i mean the project have opitons CRUD, rate, create profile, manage books(edit,delete).


# Future features
- Comments
- Forum
- Chat

I hope everyone enjoy of the project inspired by the good times where everyone were used windows XP.

#Git bash

#git clone https://github.com/levski1914/React-project.git

#cd book

#npm install

#npm run dev / npm start
